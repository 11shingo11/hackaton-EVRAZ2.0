const pg = require('pg');
const connectionString = process.env.DATABASE_URL || 'postgres://localhost:5432/mydb';

const client = new pg.Client(connectionString);
client.connect();

const query = client.query(
  'SELECT * FROM users',
  (err, res) => {
    if (err) throw err;

    const htmlTable = `<table>`;

    for (let row of res.rows) {
      htmlTable += `<tr>`;

      for (let colName in row) {
        htmlTable += `<td>${row[colName]}</td>`;
      }

      htmlTable += `</tr>`;
    }

    htmlTable += `</table>`;

    console.log(htmlTable); // выводим таблицу в консоль

    document.getElementById('table').innerHTML = htmlTable; // выводим таблицу на страницу HTML

    client.end(); // закрываем соединение с БД PostgreSQL  
});