const ctx4 = document.getElementById('chart_4').getContext('2d');
const chart_4 = new Chart(ctx4, {
    type: 'bar',
    data: {
        labels: ['% поломок', 't воды', 'д. разряжения', 'д. вибрации'],
        datasets: [{
            label: '# Эксгаустер У-171',
            data: [90, 84, 50, 73],
            backgroundColor: [
                'rgba(255, 0, 0, 0.8)',
                'rgba(0, 255, 0, 0.8)',
                'rgba(0, 255, 0, 0.8)',
                'rgba(0, 255, 0, 0.8)'

            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'

            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});