def graf(df):
  # Загружаем обработанный мапинг (только подшипники) на каждый Эксгаустер
  df_map_Y_171 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 1 (У-171)')
  df_map_Y_172 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 2 (У-172)')
  df_map_F_171 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 3 (Ф-171)')
  df_map_F_172 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 4 (Ф-172)')
  df_map_Х_171 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 5 (X-171)')
  df_map_Х_172 = pd.read_excel('/content/drive/MyDrive/ЕВРАЗ_2.0/Маппинг сигналов ред.xlsx', sheet_name='Эксгаустер № 6 (X-172)')

  # Отсортируем данные для каждого Эксгаустера из общих данных с kafka
  df_Y_171 = df[df_map_Y_171['Код сигнала в Kafka'].unique()] # Оставляем только уникальные столбцы (сигналы) для Эксгаустера Y 171 в общей базе  
  df_Y_171.insert(0, 'moment', df['moment']) # Ставим столбец даты первым
  df_Y_171['moment'] = pd.to_datetime(df_Y_171['moment']) # Переводим даты из формата кафки в формат datatime 

  df_Y_172 = df[df_map_Y_172['Код сигнала в Kafka'].unique()]
  df_Y_172.insert(0, 'moment', df['moment'])
  df_Y_172['moment'] = pd.to_datetime(df_Y_172['moment'])

  df_F_171 = df[df_map_Y_171['Код сигнала в Kafka'].unique()]
  df_F_171.insert(0, 'moment', df['moment'])
  df_F_171['moment'] = pd.to_datetime(df_F_171['moment'])

  df_F_172 = df[df_map_Y_172['Код сигнала в Kafka'].unique()]
  df_F_172.insert(0, 'moment', df['moment'])
  df_F_172['moment'] = pd.to_datetime(df_F_172['moment'])

  df_X_171 = df[df_map_Y_171['Код сигнала в Kafka'].unique()]
  df_X_171.insert(0, 'moment', df['moment'])
  df_X_171['moment'] = pd.to_datetime(df_X_171['moment'])

  df_X_172 = df[df_map_Y_172['Код сигнала в Kafka'].unique()]
  df_X_172.insert(0, 'moment', df['moment'])
  df_X_172['moment'] = pd.to_datetime(df_X_172['moment'])

  # Переименовываем столбцы на одно название для последующего объекдинения
  df_Y_172.columns = df_Y_171.columns
  df_F_171.columns = df_Y_171.columns
  df_F_172.columns = df_Y_171.columns
  df_X_171.columns = df_Y_171.columns
  df_X_172.columns = df_Y_171.columns

  # Объединяем все столбцы в один df
  df_ag_all = pd.concat([df_Y_171, df_Y_172], ignore_index=True)
  df_ag_all = pd.concat([df_ag_all, df_F_171], ignore_index=True)
  df_ag_all = pd.concat([df_ag_all, df_F_172], ignore_index=True)
  df_ag_all = pd.concat([df_ag_all, df_X_171], ignore_index=True)
  df_ag_all = pd.concat([df_ag_all, df_X_172], ignore_index=True)

  # Загрузим исправленные значения
  df_pok = pd.read_csv('/content/drive/MyDrive/ЕВРАЗ_2.0/Показания_У-171.txt', sep=',')
  
  # Создадим df трейн
  df_t = df_ag_all[df_pok['код сигнала']]

  # Создаём словарь из значений
  keys = df_pok['код сигнала'].to_list()
  values = df_pok['Название сигнала'].to_list()
  name_sig_dict = dict(zip(keys, values))
  #Переименовываем столбцы согласно словарю
  df_t.rename(columns = name_sig_dict, inplace = True )

  data = np.array(d_t)

  #Отображаем исходные от точки start и длинной stop
  start = 0            #С какой точки начинаем
  #stop = data.shape[0] #Сколько точек отрисуем
  length = 50 #Сколько точек отрисуем

  #Заполняем текстовые названия каналов данных
  chanelNames = df_t.columns# Название столбцов для отрисовки

  #Рисуем все графики данных
  # Показания по столбцам
  plt.figure(figsize=(22,6))
  for i in range(len(df_t.columns)): # количество столбцов в df_t
    #Отрисовываем часть данных
    #От начальной точки, до начальной точки + размер шага отрисовки
    plt.plot(data[start:start+length,i], 
          label=chanelNames[i])
  plt.ylabel('Показания')
  plt.legend()
  plt.show()

##################################################
from confluent_kafka import Consumer

cfg = {
    'bootstrap.servers': 'rc1a-2ar1hqnl386tvq7k.mdb.yandexcloud.net:9091', # host = 'rc1a-2ar1hqnl386tvq7k.mdb.yandexcloud.net:9091'
    'group.id': 'win_win_win',
    'auto.offset.reset': 'earliest',
    'security.protocol': 'SASL_SSL',
    'ssl.ca.location' : 'CA.pem',
    'sasl.username' : '9433_reader',
    'sasl.password': 'eUIpgWu0PWTJaTrjhjQD3.hoyhntiK',
    'sasl.mechanisms':'SCRAM-SHA-512'
}

C = Consumer(cfg)
C.subscribe(['zsmk-9433-dev-01'])

#%%time
list_msg = []
for _ in tqdm(range(5)):
    msg = C.poll(1)
    if msg:
        dat = {
            'msg_value': msg.value(),
            'msg_headers': msg.headers(),
            'msg_key': msg.key(),
            'msg_partition': msg.partition(),
            'msg_topic': msg.topic(),        
        }
        data = json.loads(msg.value().decode('utf-8'))
        list_msg.append(data)
        df = pd.DataFrame(list_msg)
    graf(df)